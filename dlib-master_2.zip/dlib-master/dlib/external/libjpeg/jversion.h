/*
 * jversion.h
 *
 * Copyright (C) 1991-2022, Thomas G. Lane, Guido Vollbeding.
 * This file is part of the Independent JPEG Group's software.
 * For conditions of distribution and use, see the accompanying README file.
 *
 * This file contains software version identification.
 */


#define JVERSION	"9e  16-Jan-2022"

#define JCOPYRIGHT	"Copyright (C) 2022, Thomas G. Lane, Guido Vollbeding"
